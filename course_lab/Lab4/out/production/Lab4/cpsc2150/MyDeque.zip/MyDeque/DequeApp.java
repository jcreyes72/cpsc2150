// CPSC 2151
// Group Members: Ryan Le, Julio Reyes

package cpsc2150.MyDeque;
import java.util.Scanner;


public class DequeApp {
    public static void main(String args[]){
        IDeque q;
    /*You will add in code here to ask the user whether they want an array implementation or a list implementation.
    Then use their answer to initialize q appropriately*/

        Scanner in = new Scanner(System.in);//initializes scanner variable to check selection
        System.out.println("Please type desired storage type: List or Array. \n Please type in selection exactly as prompted.");//prompt text
        String userIn = in.next();//sets response to scanner variable

        if(userIn.equals("Array"))//if checks if entry is array
        {
            q = new ArrayDeque();//q initialized as array
        }
        else if(userIn.equals("List"))//if checks if entry is list
        {
            q = new ListDeque();//q initialized as list
        }else//no other acceptable answers, so error prompt
        {
            System.out.println("Please re-enter your desired storage type exactly as indicated.");//error prompt
            return;//exits program
        }
        Character x = 'a';
        q.enqueue(x);
        x = 'k';
        q.enqueue(x);
        x = 'j';
        q.enqueue(x);
        x = '1';
        q.enqueue(x);
        x = 'f';
        q.enqueue(x);
        //Add the code to print the deque. After the code is finished, the deque
        // should still contain all its values in order


        System.out.println(q);


        // Displaying menu for user to edit deque
        System.out.println("\nMENU:\n" + "" +
                "i. Add to the end of the deque\n" +
                "ii. Add to the front of the deque\n" +
                "iii. Remove from the front of the deque\n" +
                "iv. Remove from the end of the deque\n" +
                "v. Peek at the front of the deque\n" +
                "vi. Peek at the end of the deque\n" +
                "vii. Insert into a position in the deque\n" +
                "viii. Remove a value from any position in the deque and return it\n" +
                "ix. Peek at a value at any position in the deque\n" +
                "x. Returns the length of the deque\n" +
                "xi. Clears the deque\n" +
                "xii. Exit\n");

        // Getting input from scanner
        userIn = in.next();

        q.peek();


        while (true) {
            // i. Add to the end of the deque
            if (userIn.equals("1")) {
                System.out.println("\n What number would you like to add to the end of the deque?");
                userIn = in.next();
                q.enqueue(userIn.charAt(0));
                System.out.println("The deque is now: " + q);
            }


        }
    }
}