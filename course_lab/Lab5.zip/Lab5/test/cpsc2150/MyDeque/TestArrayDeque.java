package cpsc2150.MyDeque;
import cpsc2150.MyDeque.ArrayDeque;
import cpsc2150.MyDeque.IDeque;
import org.junit.Test;
import static org.junit.Assert.assertTrue;



public class TestArrayDeque {


    private IDeque<Character> MakeADeque(){
        // Creating our object
        IDeque<Character> newObject = new ArrayDeque();
        return newObject;
    }


    // In this test we will enqueue the max amount of values
    // into our deque
    @Test
    public void enqueueTestMax(){

        // Creating a new object
        IDeque q = MakeADeque();
        // String that we will compare with our q.toString()
        String strCompare = "";

            // Filling both strCompare and q with same values
            for (int i = 0; i < 100; i++){
                q.enqueue('x');
                strCompare += "x, ";
            }

        // Removing the trailing comma and space that will be at the end of
        // strCompare from our loop
        strCompare = strCompare.substring(0, strCompare.length() - 2);

        // Comparing our two strings
        assertTrue(q.toString().equals(strCompare));

    }


    // In this test we will enqueue the median number of values
    // into our deque
    @Test
    public void enqueueTestMedian(){

        // Creating a new object
        IDeque q = MakeADeque();
        // String that we will compare with our q.toString()
        String strCompare = "";

            // Filling both strCompare and q with same values
            for (int i = 0; i < 50; i++){
                q.enqueue('x');
                strCompare += "x, ";
            }

        // Removing the trailing comma and space that will be at the end of
        // strCompare from our loop
        strCompare = strCompare.substring(0, strCompare.length() - 2);

        // Comparing our two strings
        assertTrue(q.toString().equals(strCompare));

    }


    // In this test we will enqueue the smallest number of values
    // into our deque, i.e just one value. We felt this was a distinct
    // case since it ensures our deque is removing extra space/commas when
    // given only 1 input
    @Test
    public void enqueueTestMin(){

        // Creating a new object and enqueuing value
        IDeque q = MakeADeque();
        q.enqueue('x');

        // Seeing if value is the same
        assertTrue(q.toString().equals("x"));

    }

    // In this test we will fill our deque and make sure that the last
    // value is returned successfully and that our deque has been updated
    @Test
    public void dequeueTestMax(){

        // Creating a new object
        IDeque q = MakeADeque();
        // String that we will compare with our q.toString()
        String strCompare = "";

            // Filling both strCompare and q with same values
            for (int i = 0; i < 100; i++){
                q.enqueue('x');
                strCompare += "x, ";
            }

        // Removing the trailing comma, space, and extra value that will be
        // removed from our deque
        strCompare = strCompare.substring(0, strCompare.length() - 5);

        assertTrue(q.dequeue().equals('x'));
        assertTrue(q.toString().equals(strCompare));
    }

    // In this test we will fill our deque with two values and make sure
    // that our dequeue() results in the value being returned successfully
    // and that our deque has been updated
    @Test
    public void dequeueTestTwo(){

        // Creating a new object and filling with two values
        IDeque q = MakeADeque();
        q.enqueue('x');
        q.enqueue('y');

        assertTrue(q.dequeue().equals('x'));
        assertTrue(q.toString().equals("y"));


    }


    // In this test we will fill our deque with only one value and make sure
    // that our dequeue results in the deque being completely empty and that
    // the single value we have entered is returned
    @Test
    public void dequeueTestEmpty(){

        // Creating a new object and filling it with a single value
        IDeque q = MakeADeque();
        q.enqueue('x');

        assertTrue(q.dequeue().equals('x'));
        assertTrue(q.toString().equals(" "));
    }


   // In this test we will fill our deque with the "maximum - 1" amount of values
   // and make sure that our inject method puts our final value in the correct place
   @Test
   public void injectTestMax(){

       // Creating a new object
       IDeque q = MakeADeque();
       // String that we will compare with our q.toString(), adding y to the
       // front so that it can be compared once 'y' is injected into deque
       String strCompare = "y, ";

           // Filling both strCompare and q with same values
           for (int i = 0; i < 99; i++){
               q.enqueue('x');
               strCompare += "x, ";
           }

       // Removing the trailing comma and space from our string
       strCompare = strCompare.substring(0, strCompare.length() - 2);

       q.inject('y');

       assertTrue(q.toString().equals(strCompare));

   }


   // In this test we will inject our deque with two values to make sure
   // our inject is placing characters in the correct position of our deque
   @Test
   public void injectTestTwo(){

        //Creating new object and injecting two characters
        IDeque q = MakeADeque();
        q.inject('x');
        q.inject('y');

        assertTrue(q.toString().equals("y, x"));

   }


   // In this test we will inject our deque with one value to make sure
   // it is being our character is being formatted correctly when placed
   // into an empty deque
   @Test
   public void injectTestEmpty(){

        // Creating new object and injecting our character
        IDeque q = MakeADeque();
        q.inject('x');

        assertTrue(q.toString().equals("x"));

   }

   // In this test we will be be removing the last element of a full
   // deque to ensure that our program can locate and delete the last
   // element when the maximum number of values have been placed in
   @Test
   public void removeLastTestMax(){

        // Creating new object
        IDeque q = MakeADeque();
        // Creating our string which will be used to compare values
        String strCompare = "";

           // Filling both strCompare and q with same values
           for (int i = 0; i < 100; i++){
               q.enqueue('x');
               strCompare += "x, ";
           }

       // Removing the trailing comma, space, and extra value that will be
       // removed from our deque
       strCompare = strCompare.substring(0, strCompare.length() - 5);

       assertTrue(q.removeLast().equals('x'));
       assertTrue(q.toString().equals(strCompare));

   }


   // In this test we will be removing the last element in a deque which
   // contains only two values
   @Test
   public void removeLastTestTwo(){

       //Creating new object and enqueueing two characters
       IDeque q = MakeADeque();
       q.enqueue('x');
       q.enqueue('y');

       assertTrue(q.removeLast().equals('y'));
       assertTrue(q.toString().equals("x"));

   }


   // In this test we will be removing the last element in a deque which
   // contains only one value, so that we can make sure the deque is emptied
   // correctly
   @Test
   public void removeLastTestEmpty(){

       // Creating new object and enqueueing our character
       IDeque q = MakeADeque();
       q.enqueue('x');

       assertTrue(q.removeLast().equals('x'));
       assertTrue(q.toString().equals(" "));

   }


   // In this test we will be clearing a deque which contains the maximum
   // number of values
   @Test
   public void clearTestMax(){

       // Creating new object
       IDeque q = MakeADeque();

       // Filling q with the maximum number of values
       for (int i = 0; i < 100; i++){
           q.enqueue('x');
       }

       q.clear();

       assertTrue(q.toString().equals(" "));

   }

   // In this test we will be clearing a deque which contains only two values
   @Test
   public void clearTestTwo(){

       //Creating new object and enqueueing two characters
       IDeque q = MakeADeque();
       q.enqueue('x');
       q.enqueue('y');

       q.clear();

       assertTrue(q.toString().equals(" "));

   }


   // In this test we will be clearing a deque which contains only one value
    @Test
    public void clearTestEmpty(){

        // Creating new object and enqueueing our character
        IDeque q = MakeADeque();
        q.enqueue('x');

        q.clear();

        assertTrue(q.toString().equals(" "));

    }


    
}
